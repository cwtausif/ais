<?php session_start(); ?>
<?php include('database.php'); ?> 
<?php include('header.php'); ?>        
<?php
if (isset($_SESSION['userais']) && !empty($_SESSION['userais'])) {
    echo("<script>location.href = 'index.php';</script>");     
}
?>      <style>
    body{
        background-color: #5b5077;
    }
</style>        
        <h1 style="
                color: wheat;
                font-family: initial;
            ">Awareness of Illness Scale(AIS) Admin Panel Login</h1>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-12">
                    <form class="form-horizontal" action="login.php" method="post">
                        <fieldset>
                            <div class="input-group input-group-lg">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-user red"></i></span>
                                <input type="text" name="email" class="form-control" placeholder="Email">
                            </div>
                            <div class="clearfix"></div><br>

                            <div class="input-group input-group-lg">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-lock red"></i></span>
                                <input name="password" type="password" class="form-control" placeholder="Password">
                            </div>
                            <div class="clearfix"></div>

                            
                            <div class="clearfix"></div><br>

                            <p class="center col-md-5">
                                <button type="submit" class="btn btn-primary">Login</button>
                            </p>
                            <div id="info" style="color: white;"></div>
                        </fieldset>
                    </form>
                </div>
            </div>

<?php
if(!empty($_POST)){
    
    $email = $_POST['email'];
    $password = $_POST['password'];
    
   $query = "SELECT * from ais_users where email = '$email' AND password = '$password' AND type=1";
   
    $result = mysqli_query($conn, $query);
   
    if ($result->num_rows > 0){
        $_SESSION['userais'] = $email;
     
          session_commit();
          echo("<script>location.href = 'index.php';</script>");
    } else {
        echo "<script> document.getElementById('info').innerHTML ='Invalid Login Detail'; </script>";
        
    }
}    
?>        