-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 05, 2018 at 10:30 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `glowingsoft_ihelp`
--

-- --------------------------------------------------------

--
-- Table structure for table `accessories_repairs`
--

CREATE TABLE `accessories_repairs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` int(11) NOT NULL,
  `type` int(11) NOT NULL DEFAULT '1',
  `city` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accessories_repairs`
--

INSERT INTO `accessories_repairs` (`id`, `name`, `location`, `type`, `city`) VALUES
(1, 'Arslan Mobile Repairs', 42, 1, 'Lahore'),
(2, 'dehli computers', 43, 1, 'Dehli'),
(3, 'Japan Electronics', 44, 1, 'Bbbb'),
(4, 'hafiz electronics', 45, 1, 'Lahore');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `type`) VALUES
(1, 'admin@accubet.com', 'bet123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ais_users`
--

CREATE TABLE `ais_users` (
  `id` int(11) NOT NULL,
  `email` varchar(500) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `type` int(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ais_users`
--

INSERT INTO `ais_users` (`id`, `email`, `password`, `type`) VALUES
(1, 'ais@admin.com', '123456', 1),
(3, 'cwtausif@gmail.com', '123456', 2),
(4, 'one@gmail.com', '123456', 2),
(5, 'two@gmail.com', '123456', 2),
(6, 'Akhan@nki.rfmh.org', '123456', 2);

-- --------------------------------------------------------

--
-- Table structure for table `car_repairs`
--

CREATE TABLE `car_repairs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `car_repairs`
--

INSERT INTO `car_repairs` (`id`, `name`, `location`) VALUES
(1, 'almajed', 13),
(2, 'dino', 14),
(3, 'Honda', 15),
(4, 'Honda', 16),
(5, 'civic', 17),
(6, 'Mercedes-Benz', 18),
(7, 'suzuki', 19),
(8, 'ayaxso', 20),
(9, 'saudi', 21),
(10, 'kaghiztan', 22),
(11, 'iran', 23),
(12, 'sudan', 24),
(13, 'libia', 25),
(14, 'new dehli', 26),
(15, 'dubai', 27),
(16, 'south Africa', 28),
(17, 'uk', 29),
(18, 'bejing', 30),
(19, 'Arslan', 33),
(20, 'fire stone auto workshop', 41),
(21, 'test', 46),
(22, 'sonata', 52);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `title`) VALUES
(1, 'Computer Science'),
(2, 'Math'),
(3, 'English'),
(4, 'Spanish');

-- --------------------------------------------------------

--
-- Table structure for table `dictionary_admin`
--

CREATE TABLE `dictionary_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(500) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `type` int(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dictionary_admin`
--

INSERT INTO `dictionary_admin` (`id`, `email`, `password`, `type`) VALUES
(1, 'admin@dictionary.com', '123456', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dictionary_words`
--

CREATE TABLE `dictionary_words` (
  `id` int(255) NOT NULL,
  `term` varchar(500) DEFAULT NULL,
  `meaning` text,
  `example` text,
  `category` int(1) NOT NULL DEFAULT '1',
  `status` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `dictionary_words`
--

INSERT INTO `dictionary_words` (`id`, `term`, `meaning`, `example`, `category`, `status`) VALUES
(20, 'ABD', 'Away from', 'Abduction', 1, 1),
(22, 'victem', 'surgical ', 'annop', 2, 1),
(24, 'amir', 'ali', 'asd', 2, 1),
(26, 'rehmat', 'barkat', 'rdp', 1, 1),
(28, 'PTCL', 'pakistan telecummuncation limited', 'internet', 3, 1),
(30, 'haadi', 'axha', 'ma axha hn', 1, 1),
(31, 'Good', 'HHHHHh', 'AAAAAAA', 2, 1),
(32, 'Ustad', 'Teacher', 'Ustad is teacher', 1, 1),
(34, 'Ganja', 'Without hair', 'Faisalganjah', 1, 1),
(35, 'lahore', 'city of pakistan', 'city of acontry', 3, 1),
(36, 'ahmad', 'ali', 'ahhh', 1, 1),
(37, 'PSL', 'Pakistan Supper Leauge', 'PCB Event', 1, 1),
(38, 'UBL', 'united bank limited', 'swhswj', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `location_id` int(11) NOT NULL,
  `location` text,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `formatted_address` text,
  `country` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `zoom` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`location_id`, `location`, `latitude`, `longitude`, `formatted_address`, `country`, `state`, `zipcode`, `city`, `address`, `zoom`) VALUES
(1, 'Street 117', 31.4993446, 74.3460547, 'Street 117, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Street 117', 0),
(2, NULL, 24.9999192, 66.7845038, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(3, NULL, 31.5157564, 74.3407344, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(4, NULL, 31.5157564, 74.3407344, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(5, NULL, 31.5201733, 74.3208461, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(6, NULL, 31.515966, 74.3392823, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(7, NULL, 31.515966, 74.3392823, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(8, NULL, 31.5010202, 74.3194017, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(9, NULL, 31.5010202, 74.3194017, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(10, NULL, 24.9999192, 66.7845038, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(11, NULL, 31.99, 31.88, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(12, NULL, 31.99, 31.88, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(13, NULL, 31.99, 31.88, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(14, 'Office # 22, 5th Floor, Gohar Center Wahdat Road', 31.5205662, 74.32303329999999, 'Office # 22, 5th Floor, Gohar Center Wahdat Road, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Office # 22, 5th Floor, Gohar Center Wahdat Road', 0),
(15, 'Multan Road', 31.460334099999997, 74.2225181, 'Multan Road, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Multan Road', 0),
(16, 'Multan Road', 31.460334099999997, 74.2225181, 'Multan Road, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Multan Road', 0),
(17, '900 Civic Center Drive', 42.0243058, -87.8015442, '900 Civic Center Drive, Niles United States', 'United States', NULL, NULL, 'Niles', '900 Civic Center Drive', 0),
(18, '201 South Texas Avenue', 26.1497977, -97.91361119999999, '201 South Texas Avenue, Mercedes United States', 'United States', NULL, NULL, 'Mercedes', '201 South Texas Avenue', 0),
(19, 'Solapur - Pune Highway', 18.506745, 73.899835, 'Solapur - Pune Highway, Pune India', 'India', NULL, NULL, 'Pune', 'Solapur - Pune Highway', 0),
(20, 'Alemdar Mahallesi', 41.0082376, 28.9783589, 'Alemdar Mahallesi, null Turkey', 'Turkey', NULL, NULL, NULL, 'Alemdar Mahallesi', 0),
(21, '19212', 23.885942, 45.079162000000004, '19212, null Saudi Arabia', 'Saudi Arabia', NULL, NULL, NULL, '19212', 0),
(22, 'Toktogul Street', 42.8746212, 74.5697617, 'Toktogul Street, Bishkek Kyrgyzstan', 'Kyrgyzstan', NULL, NULL, 'Bishkek', 'Toktogul Street', 0),
(23, 'Tehran Province', 35.6891975, 51.38897359999999, 'Tehran Province, Tehran Iran', 'Iran', NULL, NULL, 'Tehran', 'Tehran Province', 0),
(24, 'Khartoum Bahri', 15.7937709, 32.8986812, 'Khartoum Bahri, null Sudan', 'Sudan', NULL, NULL, NULL, 'Khartoum Bahri', 0),
(25, 'Baladia Street', 32.887209399999996, 13.191338300000002, 'Baladia Street, Tripoli Libya', 'Libya', NULL, NULL, 'Tripoli', 'Baladia Street', 0),
(26, 'Rajpath', 28.6139391, 77.2090212, 'Rajpath, New Delhi India', 'India', NULL, NULL, 'New Delhi', 'Rajpath', 0),
(27, 'Downtown Dubai', 25.1975148, 55.274873199999995, 'Downtown Dubai, Dubai United Arab Emirates', 'United Arab Emirates', NULL, NULL, 'Dubai', 'Downtown Dubai', 0),
(28, '107 Albertina Sisulu Road', -26.204102799999998, 28.0473051, '107 Albertina Sisulu Road, Johannesburg South Africa', 'South Africa', NULL, NULL, 'Johannesburg', '107 Albertina Sisulu Road', 0),
(29, '57 Trafalgar Square', 51.5073509, -0.1277583, '57 Trafalgar Square, London United Kingdom', 'United Kingdom', NULL, NULL, 'London', '57 Trafalgar Square', 0),
(30, 'Chaoyang, Beijing', 40.0798573, 116.60311209999999, 'Chaoyang, Beijing, Chaoyang China', 'China', NULL, NULL, 'Chaoyang', 'Chaoyang, Beijing', 0),
(31, 'Zafar Street', 31.5216187, 74.3223299, 'Zafar Street, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Zafar Street', 0),
(32, 'Ferozepur Road', 31.5220865, 74.3238655, 'Ferozepur Road, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Ferozepur Road', 0),
(33, 'Zafar Street', 31.521694099999998, 74.3226016, 'Zafar Street, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Zafar Street', 0),
(34, 'Multan Road', 31.4253731, 74.1762944, 'Multan Road, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Multan Road', 0),
(35, 'Hira Lal Road', 24.8614622, 67.0099388, 'Hira Lal Road, Karachi Pakistan', 'Pakistan', NULL, NULL, 'Karachi', 'Hira Lal Road', 0),
(36, 'Rajpath', 28.6139391, 77.2090212, 'Rajpath, New Delhi India', 'India', NULL, NULL, 'New Delhi', 'Rajpath', 0),
(37, 'Katchehry Road', 30.198380699999994, 71.46870280000002, 'Katchehry Road, Multan Pakistan', 'Pakistan', NULL, NULL, 'Multan', 'Katchehry Road', 0),
(38, 'Strada Frigoriferului', 45.7983273, 24.125582599999998, 'Strada Frigoriferului, Sibiu Romania', 'Romania', NULL, NULL, 'Sibiu', 'Strada Frigoriferului', 0),
(39, '2 Zheng Yi Lu', 39.904211, 116.407395, '2 Zheng Yi Lu, Dongcheng China', 'China', NULL, NULL, 'Dongcheng', '2 Zheng Yi Lu', 0),
(40, 'Street 117', 40.712783699999996, -74.0059413, 'Street 117, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Street 117', 0),
(41, '1233 Melbourne Road', 32.8324187, -97.19776850000001, '1233 Melbourne Road, Hurst United States', 'United States', NULL, NULL, 'Hurst', '1233 Melbourne Road', 0),
(42, '55 Main Boulevard Gulberg', 31.516065799999993, 74.3429884, '55 Main Boulevard Gulberg, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', '55 Main Boulevard Gulberg', 0),
(43, 'Zafar Street', 28.628965299999997, 77.136596, 'Zafar Street, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Zafar Street', 0),
(44, '2 Chome-8-1 Nishishinjuku', 35.6894875, 139.6917064, '2 Chome-8-1 Nishishinjuku, Shinjuku Japan', 'Japan', NULL, NULL, 'Shinjuku', '2 Chome-8-1 Nishishinjuku', 0),
(45, 'Office # 22, 5th Floor, Gohar Center Wahdat Road', 31.520102, 74.322417, 'Office # 22, 5th Floor, Gohar Center Wahdat Road, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Office # 22, 5th Floor, Gohar Center Wahdat Road', 0),
(46, '1585 Charleston Road', 37.4200757, -122.08241299999999, '1585 Charleston Road, Mountain View United States', 'United States', NULL, NULL, 'Mountain View', '1585 Charleston Road', 0),
(47, 'Street 9, Gulshan Block', 31.5145126, 74.292908, 'Street 9, Gulshan Block, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Street 9, Gulshan Block', 0),
(48, 'Street 9, Gulshan Block', 31.5145133, 74.2929077, 'Street 9, Gulshan Block, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Street 9, Gulshan Block', 0),
(49, 'Street 9, Gulshan Block', 31.5145127, 74.2929073, 'Street 9, Gulshan Block, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Street 9, Gulshan Block', 0),
(50, 'Zafar Street', 31.5214509, 74.3224998, 'Zafar Street, Lahore Pakistan', 'Pakistan', NULL, NULL, 'Lahore', 'Zafar Street', 0),
(51, '3101-3199 East Rosedale Street', 32.7314673, -97.2799964, '3101-3199 East Rosedale Street, Fort Worth United States', 'United States', NULL, NULL, 'Fort Worth', '3101-3199 East Rosedale Street', 0),
(52, '3101-3199 East Rosedale Street', 32.7314673, -97.2799964, '3101-3199 East Rosedale Street, Fort Worth United States', 'United States', NULL, NULL, 'Fort Worth', '3101-3199 East Rosedale Street', 0),
(53, NULL, 31.5215303, 74.3196584, 'null, null null', NULL, NULL, NULL, NULL, NULL, 0),
(54, NULL, 31.5220183, 74.3194883, 'null, null null', NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `matches`
--

CREATE TABLE `matches` (
  `id` int(255) NOT NULL,
  `league` varchar(500) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `date` date DEFAULT NULL,
  `teama` varchar(500) DEFAULT NULL,
  `teamb` varchar(500) DEFAULT NULL,
  `prediction` varchar(500) DEFAULT NULL,
  `odds` varchar(500) DEFAULT NULL,
  `dailybonus` int(1) NOT NULL DEFAULT '2',
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `matches`
--

INSERT INTO `matches` (`id`, `league`, `time`, `date`, `teama`, `teamb`, `prediction`, `odds`, `dailybonus`, `status`) VALUES
(1, 'Premier League', '01:00:00', '2017-06-22', 'Manchestar United', 'Chelsea FC', '2', '2.3', 2, 1),
(6, 'Premier League', '01:00:00', '2017-06-30', 'Manchestar United', 'Chelsea FC', '2', '4.5', 2, 2),
(9, 'EPL', '21:15:00', '2017-06-18', 'Arsenal', 'Man Utd', '2', '1.67', 2, 1),
(10, 'IPL', '01:00:00', '2017-06-17', 'Ponnay', 'Riders', 'Draw', '6.5', 2, 0),
(11, 'Premier League', '08:00:00', '2017-06-19', 'Manchestar United', 'UK Club', 'draw', '2.1', 1, 1),
(12, 'England: EPL', '17:00:00', '2017-06-20', 'Man City', 'Liverpool', 'HT Under 1.5 Goals', '1.21', 2, 1),
(13, 'UEFA 21 Championship', '19:45:00', '2017-06-22', 'Slovakia U21', ' Sweden U21', 'Draw', '1.1', 1, 0),
(14, 'FIFA Confederations Cup', '16:00:00', '2017-06-22', 'Cameroon', 'Australia', 'Draw', '2.2', 1, 0),
(15, 'Premier League', '01:00:00', '2017-07-14', 'Manchestar United', 'Australia', 'Draw', '1.7', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(255) NOT NULL,
  `question` longtext,
  `question_main` int(11) NOT NULL,
  `part` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `question_main`, `part`) VALUES
(4, 'When people disagree with me, I am right and they are wrong.', 1, 'Insight'),
(5, 'I am right when people disagree with me.', 1, 'Insight'),
(6, 'Any unusual experiences I have may be due  to me being sad or upset.', 2, 'Insight'),
(27, 'I feel when people disagree with me, they are wrong and I am right.', 1, 'Insight'),
(28, 'I feel when people disagree with me, they are wrong and I am right.', 1, 'Insight'),
(29, 'Any unusual feelings I have are only because I am sad or stressed.', 2, 'Insight'),
(30, 'If I have unusual experiences it is because I am sad or upset.', 2, 'Insight'),
(31, 'My thoughts feel like my own.', 6, 'Insight'),
(32, 'I feel it is hard to explain to people what I am thinking.', 6, 'Insight'),
(35, 'I feel like breaking things.', 5, 'Insight'),
(36, 'I feel I do not need to take my medications.', 3, 'Insight'),
(37, 'I do not feel I need to take medications.', 3, 'Insight'),
(38, 'I feel I only take medications because the doctor told me to.', 3, 'Insight'),
(39, 'I do not feel my medications do not really help me.', 3, 'Insight'),
(40, 'I do not need to take medications for a psychiatric or mental illness.', 3, 'Insight'),
(43, 'I have been smiling a lot.', 7, 'Insight'),
(44, 'I do not feel like doing anything.', 8, 'Insight'),
(46, 'I do not believe that I have a psychiatric or mental illness.', 4, 'Insight'),
(47, 'I do not believe that I have ever had a psychiatric or mental illness.', 4, 'Insight');

-- --------------------------------------------------------

--
-- Table structure for table `question_main`
--

CREATE TABLE `question_main` (
  `id` int(1) NOT NULL,
  `title` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `question_main`
--

INSERT INTO `question_main` (`id`, `title`) VALUES
(1, 'Question 1'),
(2, 'Question 2'),
(3, 'Question 4'),
(4, 'Question 3'),
(5, 'Question 5'),
(6, 'Question 6'),
(7, 'Question 7'),
(8, 'Question 8');

-- --------------------------------------------------------

--
-- Table structure for table `taxi`
--

CREATE TABLE `taxi` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `location` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxi`
--

INSERT INTO `taxi` (`id`, `name`, `email`, `city`, `location`) VALUES
(1, '', 'Ali', 'Lahore', 31),
(2, 'sadam', 'sadam@gmail.com', 'Karachi', 35),
(3, 'sehwag', 'sehwag@gmail.com', 'New Dehli', 36),
(4, 'hamza', 'hamza@gmail.com', 'Multan', 37),
(5, 'dave', 'dave@gmail.com', 'Sibi', 38),
(6, 'uoon poon', 'uoon@gmail.com', 'Bejing', 39),
(7, 'Marwan', 'marwan@gmail.com', 'New York', 40);

-- --------------------------------------------------------

--
-- Table structure for table `tutor_reviews`
--

CREATE TABLE `tutor_reviews` (
  `id` int(11) NOT NULL,
  `tutor_id` int(11) NOT NULL,
  `reviewer_id` int(11) NOT NULL,
  `review` varchar(500) DEFAULT NULL,
  `rate` int(11) DEFAULT '5'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutor_reviews`
--

INSERT INTO `tutor_reviews` (`id`, `tutor_id`, `reviewer_id`, `review`, `rate`) VALUES
(1, 1, 1, 'hi', 5),
(2, 4, 1, 'nice', 4),
(3, 3, 1, 'good english tutor', 5),
(4, 3, 1, 'fine', 3),
(5, 1, 1, 'nice', 5),
(6, 1, 1, 'very nice', 5),
(7, 1, 1, 'great job', 5),
(8, 1, 1, 'q', 1),
(9, 1, 1, 'I am addin review', 5),
(10, 4, 13, 'nice\n', 4),
(11, 7, 1, 'Excellent trainings', 5),
(12, 4, 1, 'avg', 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` text NOT NULL,
  `api_key` varchar(500) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `avatar` varchar(500) DEFAULT NULL,
  `location_id` int(11) NOT NULL DEFAULT '0',
  `user_type` int(11) NOT NULL DEFAULT '1' COMMENT 'Tutor or simple user',
  `sec_question` int(11) DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `website` varchar(500) DEFAULT NULL,
  `github` varchar(500) DEFAULT NULL,
  `linkedin` varchar(500) DEFAULT NULL,
  `twitter` varchar(500) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `api_key`, `status`, `created_at`, `avatar`, `location_id`, `user_type`, `sec_question`, `category_id`, `website`, `github`, `linkedin`, `twitter`, `description`) VALUES
(1, 'Tausif Ul Rahman', 'cwtausif@gmail.com', '$2a$11$96d1662a74f37df2a82bauhOtqmhlVnAhgai6ecyD0Gk7X3LWpKFm', '3427f0bb66dd511213101b4f9bc01fa9', 1, '2017-02-12 16:04:39', '/users/nophoto.jpg', 1, 1, 0, 1, 'glowingsoft.com', 'cwtausif', 'cwtausif', 'cwtausif', 'this is my description'),
(2, 'Alina', 'cwtausif1@gmail.com', '$2a$11$f7f6ca6f29449eb3274b3ONWGDcOE7txWhWv8YIBOcIjwEm/GXmPW', '46a89be440bd5f6db1e61237da7d9324', 1, '2017-02-12 16:29:09', '/users/nophoto.jpg', 2, 1, 0, 2, NULL, NULL, NULL, NULL, NULL),
(3, 'Akram', 'cwtausif2@gmail.com', '$2a$11$c4af84ab4ff8344662342u4ZHc5sXz8Lz2JQSMiplov6Q4VvNuI/K', '172d1f148ba931202e001122e2ba551e', 1, '2017-02-12 16:30:57', '/users/nophoto.jpg', 4, 1, 0, 3, NULL, NULL, NULL, NULL, NULL),
(4, 'Rabia', 'cwtausif3@gmail.com', '$2a$11$67045994f5aae78618e62OputSWOTHdkLUPwzmn954VsY21U671f2', '274172cd42127bf076e1b34121e70109', 1, '2017-02-12 16:40:33', '/users/nophoto.jpg', 5, 1, 0, 4, NULL, NULL, NULL, NULL, NULL),
(5, 'Julia', 'cwtausif4@gmail.com', '$2a$11$952f20fae652016ea498bujqyY7SEhNdv8buT6wSn.sPhSZGnWHue', '247b45d8e6c7c0c9411d4c939401efe2', 1, '2017-02-12 16:43:58', '/users/nophoto.jpg', 7, 1, 0, 4, NULL, NULL, NULL, NULL, NULL),
(6, 'Karina', 'cwtausif5@gmail.com', '$2a$11$2b0dad63ca5e2adbe0babeTVZbAh4FECjCy3XFKyIqcKC7s5PCARK', 'f610ffe92ff7af034275c4dec299b5c7', 1, '2017-02-12 16:44:47', '/users/nophoto.jpg', 9, 1, 0, 4, NULL, NULL, NULL, NULL, NULL),
(7, 'Arslan', 'arslan@gmail.com', '$2a$11$a7c24adb3a5ef9b294a60uUF.jjJ.TeiiElVD8SZ0DWb8mK54gmJS', 'd7876efd7db6179b761e58ef79f86871', 1, '2017-02-20 11:44:47', '/users/nophoto.jpg', 32, 1, 0, 4, NULL, NULL, NULL, NULL, NULL),
(8, 'Arslan', 'arslan@yahoo.com', '$2a$11$3fbcbd4e8a930707a25f6uCL06tPEjcs4AqGzN5Mr9JhOOW26AqTS', '5c978f2a93b1c1f142009f49ecd59edb', 1, '2017-02-20 14:27:07', '/users/nophoto.jpg', 34, 1, 0, 4, NULL, NULL, NULL, NULL, NULL),
(9, 'Acccessory Repairer', 'accessory@gmail.com', '$2a$11$cde94cb75b1cccbc4e47eul8ZS.0Ddp7YssZVLz4e7/.G93Kl0Ryq', 'd84c36023a6bdbf1c714d9aff04ba261', 1, '2017-03-21 10:55:46', '/users/nophoto.jpg', 47, 2, 0, 0, NULL, NULL, NULL, NULL, NULL),
(10, 'Ali Tutor', 'alitutor@gmail.com', '$2a$11$2a32869442d3d7c65b230uwTrgoctY9xa/jEWdzWEJHAsCOur/QmK', '488a730bf6f06129388eb29183aa1b23', 1, '2017-03-21 10:58:48', '/users/nophoto.jpg', 48, 1, 0, 0, NULL, NULL, NULL, NULL, NULL),
(11, 'Caro', 'cardriver@gmail.com', '$2a$11$043c96aeadff34c2b71d0us3hK4PccumNrhQ9FT81Htw/wgBnf0P.', '57a06597656551bc96de26d710973e11', 1, '2017-03-21 11:02:12', '/users/nophoto.jpg', 49, 2, 0, 0, NULL, NULL, NULL, NULL, NULL),
(12, 'Taxi', 'taxidriver@gmail.com', '$2a$11$7ac4129ee1d24a2a1c24eueY8w.X4F0neNkqJW3xIVZBAu8v9LSd.', 'd9744b65b37223e54734566b3e619aeb', 1, '2017-03-21 11:04:48', '/users/nophoto.jpg', 50, 4, 0, 0, NULL, NULL, NULL, NULL, NULL),
(13, 'Asim11', 'aaaleid@txwes.edu', '$2a$11$c3c4a19bf6270a4f66602Ohceg7HEzLq2SOibUai9.PP1N/DczBLK', '02d50db0be8dec3bbc46fd7dc78e6a1f', 1, '2017-03-24 16:18:56', '/users/nophoto.jpg', 51, 1, 0, 0, '\n\n\n\n\n\n\n\n\n\n\n', '', '', '', '\n\n\n'),
(14, 'Samuel', 'samuel@gmail.com', '$2a$11$cfbb69de1640c8d671495uoq5cA1TxjyIOpcAmFfrlyPnGbxGf68q', 'f2bd116164af302348fef511b75daa13', 1, '2017-04-12 03:31:07', '/users/nophoto.jpg', 53, 1, 0, 0, NULL, NULL, NULL, NULL, NULL),
(15, 'Zhang', 'zhang@gmail.com', '$2a$11$162c193bd5afea81d78ecuCunqtG94IlGufHAkRUS8DaLN5WzF7mK', 'b1c5d498014218b92ab8e0781f7a1780', 1, '2017-04-12 03:37:06', '/users/nophoto.jpg', 54, 1, 0, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `_tehrim_comments`
--

CREATE TABLE `_tehrim_comments` (
  `id` int(10) NOT NULL,
  `u_id` text NOT NULL,
  `s_id` text NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_tehrim_comments`
--

INSERT INTO `_tehrim_comments` (`id`, `u_id`, `s_id`, `comment`) VALUES
(2, 'tehrim abbas', 'status7867', 'great post'),
(5, 'tehrim abbas', 'status7867', 'Its really a great post'),
(10, 'tehrim abbas', 'status7867', 'Its really a great post'),
(11, 'tehrim abbas', 'status7867', 'Its really a great post'),
(12, 'tehrim abbas', 'Jul 12, 2017 9:53:34 PM', 'Its really a great post'),
(13, 'tehrim abbas', '1', 'Its really a great post'),
(14, 'tehrim abbas', '14', 'Its really a great post'),
(15, 'Syed Tehrim Abbas', '14', 'Its really a great post'),
(16, 'Syed Tehrim Abbas', '14', 'Its really a great post'),
(17, 'Syed Tehrim Abbas', '2', 'excellent'),
(18, 'Syed Tehrim Abbas', '3', 'nice'),
(19, 'Syed Tehrim Abbas', '2', 'ok'),
(20, 'Syed Tehrim Abbas', '2', 'nice man really'),
(21, 'Syed Tehrim Abbas', '2', 'nice man really'),
(22, 'Syed Tehrim Abbas', '2', 'awesome'),
(23, 'Syed Tehrim Abbas', '10', 'great'),
(24, 'Syed Tehrim Abbas', '3', 'wow yummy'),
(25, 'Syed Tehrim Abbas', '2', 'nice'),
(26, 'Syed Tehrim Abbas', '10', 'great'),
(27, 'Syed Tehrim Abbas', '15', 'great'),
(28, 'Syed Tehrim Abbas', '15', 'great'),
(29, 'Syed Tehrim Abbas', '2', 'preety'),
(30, 'Syed Tehrim Abbas', '9', 'hahah'),
(31, 'Syed Tehrim Abbas', '14', 'Its really a great post'),
(32, 'waseem sajjad', '17', 'nice post'),
(33, 'waseem sajjad', '2', 'wow'),
(34, 'd', '4', 'Ok'),
(35, 'Syed Tehrim Abbas', '7', 'nice'),
(36, 'Syed Tehrim Abbas', '18', 'nice image'),
(37, 'a', '21', 'great'),
(38, 'a', '21', 'great'),
(39, 'a', '21', 'great'),
(40, 'a', '21', 'great'),
(41, 'a', '21', 'great'),
(42, 'a', '21', 'great'),
(43, 'a', '21', 'great'),
(44, 'a', '21', 'great'),
(45, 'a', '21', 'great'),
(46, 'a', '23', 'Ok'),
(47, 'Syed Tehrim Abbas', '24', 'nice'),
(48, 'Syed Tehrim Abbas', '2', 'test comment'),
(49, 'Syed Tehrim Abbas', '23', 'what is this?'),
(50, 'Syed Tehrim Abbas', '24', 'nice picture really yunmy grapes'),
(51, 'Syed Tehrim Abbas', '20', 'great'),
(52, 'a', '2', 'I'),
(53, 'Syed Tehrim Abbas', '2', 'hi'),
(54, 'abdulwajid', '2', 'poputt'),
(55, 'abdulwajid', '26', 'great');

-- --------------------------------------------------------

--
-- Table structure for table `_tehrim_likes`
--

CREATE TABLE `_tehrim_likes` (
  `id` int(5) NOT NULL,
  `sid` int(10) NOT NULL,
  `uid` tinytext NOT NULL,
  `like` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_tehrim_likes`
--

INSERT INTO `_tehrim_likes` (`id`, `sid`, `uid`, `like`) VALUES
(113, 5, 'Devtehrim', 1),
(89, 17, 'Malik', 1),
(88, 9, 'Devtehrim', 1),
(92, 4, 'Devtehrim', 1),
(80, 15, 'Devtehrim', 1),
(114, 26, 'Abdulwajid', 1),
(94, 7, 'Devtehrim', 1),
(96, 23, 'A', 1);

-- --------------------------------------------------------

--
-- Table structure for table `_tehrim_status`
--

CREATE TABLE `_tehrim_status` (
  `status_id` int(11) NOT NULL,
  `status_user` text,
  `status_content` text,
  `status_likes` int(11) DEFAULT NULL,
  `status_time_stamp` text,
  `status_user_fname` text,
  `status_user_image_path` text,
  `status_image_path` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_tehrim_status`
--

INSERT INTO `_tehrim_status` (`status_id`, `status_user`, `status_content`, `status_likes`, `status_time_stamp`, `status_user_fname`, `status_user_image_path`, `status_image_path`) VALUES
(1, 'devtehrim', 'hello', 1, 'Jul 12, 2017 10:07:06 PM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/2531796136864.png'),
(2, 'devtehrim', 'hi everyone', 1, 'Jul 12, 2017 9:54:36 PM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/1639367176454.png'),
(3, 'devtehrim', 'eating pizza', 0, 'Jul 13, 2017 12:55:31 AM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/3103271185152.png'),
(4, 'devtehrim', 'eating pizza', 0, 'Jul 13, 2017 12:55:53 AM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/2351826624672.png'),
(5, 'devtehrim', 'eating pizza', 0, 'Jul 13, 2017 12:55:59 AM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/1534386892005.png'),
(6, 'devtehrim', 'eating pizza', 0, 'Jul 13, 2017 12:58:51 AM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/2566311119288.png'),
(7, 'devtehrim', 'eating pizza', 1, 'Jul 13, 2017 1:16:29 AM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/556459436715.png'),
(8, 'devtehrim', 'logo of', 0, 'Jul 13, 2017 2:12:47 AM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/4880655215922.png'),
(9, 'devtehrim', 'Funny memes', 1, 'Jul 13, 2017 9:24:40 AM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/2956338537651.png'),
(10, 'karuppiah7890', 'Hey! This is my second post!', 0, 'Jul 13, 2017 9:32:01 AM', 'Karuppiah', 'user/1132438311970.png', 'statusImages/4265768276568.png'),
(11, 'devtehrim', 'This is demo status two', 10, '07/08/2017 12:04 pm', 'Syed Tehrim Abbas', 'http://www.glowingsoft.com/tehrimposted/user/527954662400.png', 'statusImages/3046277932491.png'),
(12, 'devtehrim', 'hi', 0, 'Jul 12, 2017 9:53:34 PM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/2647285404240.png'),
(13, 'devtehrim', 'This is demo status two', 9, '07/08/2017 12:04 pm', 'Syed Tehrim Abbas', 'http://www.glowingsoft.com/tehrimposted/user/527954662400.png', 'statusImages/308993467946.jpg'),
(14, 'devtehrim', 'hi there', 0, 'Jul 13, 2017 10:53:02 PM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/3782920468730.png'),
(15, 'devtehrim', 'feeling relax after completeing this app.', 1, 'Jul 14, 2017 6:29:51 PM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/4096606713825.png'),
(16, 'devtehrim', 'This is demo status two', 10, '07/08/2017 12:04 pm', 'Syed Tehrim Abbas', 'http://www.glowingsoft.com/tehrimposted/user/527954662400.png', 'statusImages/1497114063416.jpg'),
(17, 'malik', 'Hi everyone\nwaseem is here', 1, 'Jul 15, 2017 7:25:40 PM', 'waseem sajjad', 'user/noimage.jpg', 'statusImages/3988842550993.png'),
(18, 'devtehrim', 'hi friends', 0, 'Jul 20, 2017 7:47:32 PM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/4096534636740.png'),
(19, 'devtehrim', 'nice post', 0, 'Jul 23, 2017 2:56:38 AM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/4987027772870.png'),
(20, 'a', 'good', 0, 'Jul 23, 2017 7:15:42 AM', 'a', 'user/noimage.jpg', 'statusImages/1954057419300.png'),
(21, 'a', 't', 0, 'Jul 23, 2017 7:16:28 AM', 'a', 'user/noimage.jpg', 'statusImages/4467917889630.png'),
(22, 'devtehrim', 'eating sweets', 0, 'Jul 23, 2017 6:30:42 PM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/1827994795410.png'),
(23, 'a', 'I.', 1, 'Jul 23, 2017 2:00:25 PM', 'a', 'user/noimage.jpg', 'statusImages/2245251291800.png'),
(24, 'devtehrim', 'please have a look now I am uploading a picture okay after that I will leave comments on the picture okay.\nnow I am gona to post it.', 0, 'Jul 29, 2017 2:05:45 PM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/57050127700.png'),
(25, 'devtehrim', 'eating pizza', 0, 'Jul 29, 2017 2:09:05 PM', 'Syed Tehrim Abbas', 'user/527954662400.png', 'statusImages/1890161060391.png'),
(26, 'abdulwajid', 'Learning posted api', 1, 'Aug 24, 2017 7:26:39 PM', 'abdulwajid', 'user/noimage.jpg', 'statusImages/2605712470531.png');

-- --------------------------------------------------------

--
-- Table structure for table `_tehrim_user`
--

CREATE TABLE `_tehrim_user` (
  `name` text NOT NULL,
  `image` varchar(255) NOT NULL DEFAULT 'user/noimage.jpg',
  `city` text NOT NULL,
  `user_name` text NOT NULL,
  `zip` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `_tehrim_user`
--

INSERT INTO `_tehrim_user` (`name`, `image`, `city`, `user_name`, `zip`, `email`, `password`) VALUES
('', 'user/noimage.jpg', '', '', '', '', ''),
('a', 'user/noimage.jpg', 'houston', 'a', '77338', 'djstearns7@yahoo.com', 'a'),
('abc', 'user/noimage.jpg', 'gojra', 'abc', '34232', 'abc', 'abc'),
('abdulwajid', 'user/2581655050090.png', 'gojra', 'abdulwajid', '36120', 'a@gmail.com', '123'),
('Rana wajid', 'user/noimage.jpg', 'Gojra', 'abdul_wajid', '36120', 'abdulwajid12340@gmail.com', 'abdulwajid12340'),
('d', 'user/noimage.jpg', 'houston', 'd', '77338', 'djstearns7@yahoo.com', 'd'),
('Syed Tehrim Abbas', 'user/3928952660440.png', 'Lahore', 'devtehrim', '54000', 'tehrim@gmail.com', '123456'),
('Syed Tehrim Abbas', 'user/noimage.jpg', 'Lahore', 'devtehrim23', '54000', 'tehrim@gmail.com', '123456'),
('djstearns', 'user/noimage.jpg', 'Houston', 'dj', '77338', 'djstearns7@yahoo.com', 'Djstearns'),
('Stearns', 'user/noimage.jpg', 'houston', 'dj Stearns', '77338', 'djstearns7@yahoo.com', 'dj'),
('Karuppiah', 'user/1132438311970.png', 'Chennai', 'karuppiah7890', '600102', 'karuppiah7890@gmail.com', 'karuppiah'),
('majid', 'user/noimage.jpg', 'gojra', 'majid', '34232', 'majd', '123456'),
('majidsahib', 'user/noimage.jpg', 'gojra', 'majidsahib', '36120', 'majidsahib', 'majidsahib'),
('waseem sajjad', 'user/4741907127317.png', 'lahore', 'malik', '54000', 'malik@gmail.com', 'malik123'),
('noman', 'user/noimage.jpg', 'noman', 'noman', '36120', 'nbadhir', 'noman'),
('rizwan', 'user/noimage.jpg', 'gojra', 'rizwan', '36120', 'rizwan@gmail.com', 'rizwan'),
('dj', 'user/noimage.jpg', 'houston', 'Stearns', '77338', 'djstearns7@yahoo.com', 'dj'),
('tehrim', 'user/noimage.jpg', 'Lahore', 'tehrim789', '54000', 'tehrim@gmail.com', '123456'),
('wajidsahib', 'user/noimage.jpg', 'gojra', 'wajidsahib', '36120', 'abdulwajid12340@gmail.com', 'wajidsahib'),
('Zain Ali', 'user/noimage.jpg', 'Lahore', 'zain786', '54000', 'zain@gmail.com', 'hello');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accessories_repairs`
--
ALTER TABLE `accessories_repairs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ais_users`
--
ALTER TABLE `ais_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_repairs`
--
ALTER TABLE `car_repairs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dictionary_admin`
--
ALTER TABLE `dictionary_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dictionary_words`
--
ALTER TABLE `dictionary_words`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question_main`
--
ALTER TABLE `question_main`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taxi`
--
ALTER TABLE `taxi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tutor_reviews`
--
ALTER TABLE `tutor_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `_tehrim_comments`
--
ALTER TABLE `_tehrim_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `_tehrim_likes`
--
ALTER TABLE `_tehrim_likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `_tehrim_status`
--
ALTER TABLE `_tehrim_status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `_tehrim_user`
--
ALTER TABLE `_tehrim_user`
  ADD PRIMARY KEY (`user_name`(50));

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accessories_repairs`
--
ALTER TABLE `accessories_repairs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ais_users`
--
ALTER TABLE `ais_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `car_repairs`
--
ALTER TABLE `car_repairs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dictionary_admin`
--
ALTER TABLE `dictionary_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dictionary_words`
--
ALTER TABLE `dictionary_words`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `matches`
--
ALTER TABLE `matches`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `question_main`
--
ALTER TABLE `question_main`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `taxi`
--
ALTER TABLE `taxi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tutor_reviews`
--
ALTER TABLE `tutor_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `_tehrim_comments`
--
ALTER TABLE `_tehrim_comments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `_tehrim_likes`
--
ALTER TABLE `_tehrim_likes`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `_tehrim_status`
--
ALTER TABLE `_tehrim_status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
