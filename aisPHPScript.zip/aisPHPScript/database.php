<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// Connecting to mysql database

//define('DB_USERNAME', 'root');
//define('DB_PASSWORD', 'root');
//define('DB_HOST', '"localhost:8888');
//define('DB_NAME', 'ais');
//
//
//$conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
//
// // Check for database connection error
//        if (mysqli_connect_errno()) {
//            echo "Failed to connect to MySQL: " . mysqli_connect_error();
//        } else {
//            echo "connected success";
//        }
$conn = mysqli_connect("localhost","root","root","ais_database") or die("Error " . mysqli_error($link));
?>