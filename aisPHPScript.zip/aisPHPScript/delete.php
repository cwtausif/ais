<?php 
	include('database.php');
	$id = $_GET['id'];
        $table = $_GET['table'];

	
	$query = "DELETE FROM  ".$table." WHERE id = $id";

	$result = mysqli_query($conn,$query);

	if ($result) {
		echo 'yes';
	} else {
		echo 'Faild to delete.';
	}

?>