<?php session_start(); ?>
<?php include('database.php'); ?>
<?php include('header.php'); ?>
<?php 
//Check user is logged in 
if (isset($_SESSION['userais']) && !empty($_SESSION['userais'])) {
	
} else {
	echo("<script>location.href = 'login.php';</script>");
}
?>	
	

<body style="margin:20px auto">  
<div class="container">
<div class="row header" style="text-align:center;color:green">
    <a href="adduser.php"><div class="btn btn-success btn-lg">Add New User</div></a>
</div>
<table id="myTable" class="table table-striped table-responsive" >  
        <thead>  
          <tr>  
              <th>No.</th>
			<th>email</th>
			<th>password</th>
                        <th>Action</th>	
          </tr>  
        </thead>  
        <tbody>  
        <?php
		$query = "SELECT * from ais_users where type=2 ORDER BY id ASC";
		$result = mysqli_query($conn,$query);
		$count = 1;
		if ($result->num_rows > 0) {  ?>
						<?php while ($row = mysqli_fetch_assoc($result)) { ?>
							<tr>
								
								<td><?php echo $count; ?></td>
                                                                <td><?php echo $row['email']; ?></td>
                                                                <td><?php echo $row['password']; ?></td>
                                                                <td><button type="button" class="btn btn-danger" id="<?php echo $row['id']; ?>" onclick="deleteQuestion(this)">Delete</button></td>                                                                         
							</tr>
					<?php $count= $count+1; ?>		
					<?php } ?>
			

			<?php } ?>
        </tbody>  
      </table>  
	  </div>
</body>  
<script>
$(document).ready(function(){
    $('#myTable').dataTable();
});
</script>



<script type="text/javascript">


	function deleteQuestion(elm){
		var id = elm.getAttribute('id');
		console.log('delete: '+id);
		
		var r = confirm("Are you Sure to delete?");
	    if (r == true) {
	       console.log("delete now");
	       $.ajax({
			  type: "GET",
			   url: "delete.php?id="+id+"&table=ais_users",
			  data: id,
			  cache: false,
			  success: function(dat){
			  	console.log(dat);
			  	 if (dat == "yes") {
			  	 	if(confirm('Successfully Deleted')){
					    window.location.reload();  
					}
			  	 } else {
			  	 	if(confirm('Failed to update try again!')){
					    window.location.reload();  
					}
			  	 }
			     	
			  }
			});


	    } else {
	       
	    }

	}
</script>
<?php include('footer.php'); ?>