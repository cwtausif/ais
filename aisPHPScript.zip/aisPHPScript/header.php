<!DOCTYPE html>
<html>
<head>
	<title>Dictionary</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">   
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
	<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
	<style type="text/css">
	#status_id{
		display: none;
	}
	
		ul{
			margin: 30px;
			list-style-type: none;
		}
		li{
			float: left;
			margin: 10px;
		}
	
</style>
</head>
<body>
<div class="container">

<?php 

//Logout if key exists
if (!empty($_GET) && isset($_GET['key'])&& $_GET['key']=='aXyz8Q') {
    $_SESSION['userais'] = "";
}
if (isset($_SESSION['userais']) && !empty($_SESSION['userais'])) { ?>

    <!-- Menu -->
    <div class="row">
	<ul>
		<li><a href="index.php" class="btn btn-info btn-lg">Home</a></li>
		<li><a href="addpred.php" class="btn btn-primary btn-lg">Add New Question</a></li>
                <li><a href="users.php" class="btn btn-primary btn-lg">Manage Users</a></li>
		<li><a href="login.php?key=aXyz8Q" class="btn btn-danger btn-lg">Logout</a></li>
	</ul>
    </div>
<?php } ?>