<?php
if(!empty($_POST)){
    $to = 'akhan@nki.rfmh.org';
    $subject = 'Awareness of Illness Scale';
    $message = $_POST["data"];
    $headers = "From: ".$to."\r\n" .
        "Reply-To:". $_POST["from"]. "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    
    $response  = array();
    $response["status"] = false;
    if(mail($to, $subject, $message, $headers)){
        $response["status"] = true;
        $response["message"] = "Your request has been sent successfully!!!";
    }else {
         $response["message"] = "Problem send request Please contact at: ".$to;
    }
    
    echo json_encode($response);
    exit;
}
?> 