<?php include('database.php'); ?>
<?php 

    $query = "SELECT * from question_main ORDER BY title ASC";    
    $result = mysqli_query($conn, $query);
    $response = array();
    $response["status"] = true;
    $count = 1;
    if ($result->num_rows > 0){
        $response["data"] = array();
        while($row = mysqli_fetch_assoc($result)){
                $answersQuery = "SELECT * from questions where question_main=".$row["id"];
                $answerResult = mysqli_query($conn,$answersQuery);
                //Pic question
                $questionsArray = mysqli_fetch_all($answerResult);
                
                $index=rand(0,$answerResult->num_rows-1);
                $row["question"]=$questionsArray[$index][1];
                $row["part"]=$questionsArray[$index][3];
                
                $row["title"]=$count." of ".$result->num_rows;
                // if($count==$result->num_rows){
                //     $row["next"]="Submit";
                // }
                                
        	$response["data"][] = $row;
                $count=$count+1;
        }
    } else {
       $response["status"] = false;
       $response["message"] = "No Data Found";
    }

    echo json_encode($response,true);

    exit;
?>