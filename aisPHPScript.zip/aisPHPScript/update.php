<?php 
	include('database.php');
	$id = $_GET['id'];

	$status = $_GET['status'];

	
	$query = "UPDATE  matches SET status = $status WHERE id = $id";

	$result = mysqli_query($conn,$query);

	if ($result) {
		echo 'yes';
	} else {
		echo 'Faild to update.';
	}

?>