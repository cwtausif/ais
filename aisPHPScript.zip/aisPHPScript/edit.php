<?php session_start(); ?>
<?php include('database.php'); ?>
<?php include('header.php'); ?>
<?php 
//Check user is logged in 
if (isset($_SESSION['user']) && !empty($_SESSION['user'])) {
    	
} else {
	echo("<script>location.href = 'login.php';</script>");
}
?>	


<!-- Menu -->
<div class="row">
	<ul>
		<li><a href="index.php" class="btn btn-info btn-lg">Home</a></li>
		<li><a href="addpred.php" class="btn btn-primary btn-lg">Add New Word</a></li>
		<li><a href="login.php?key=aXyz8Q" class="btn btn-danger btn-lg">Logout</a></li>
	</ul>
</div>	

<?php

if(!empty($_POST) && isset($_GET['update'])){
   
   
    $term = $_POST['term'];
    $meaning = $_POST['meaning'];
    $example = $_POST['example'];
    $category = $_POST['category'];
    $id = $_POST['id'];

    $query = "UPDATE `dictionary_words` SET `term` = '$term', `meaning` = '$meaning', `example` = '$example' , `category` = $category WHERE `dictionary_words`.`id` = $id;";

   // $query = "INSERT INTO `dictionary_words` (`id`, `term`, `meaning`, `example`) VALUES (NULL, '$term', '$meaning', '$example');";
    $result = mysqli_query($conn,$query);

    if ($result) {
      //header('Location: index.php');
      echo "<div class='alert alert-success'>Successfuly Updated</div>";
      //echo("<script>location.href = 'index.php';</script>");
    } else {
      echo "Failed to save record";
    }

}
 ?>


<?php
 $id = $_GET['id'];
 if($id==""){
  echo "Invalid id";
exit;
 }
$query = "SELECT * FROM dictionary_words where id = $id limit 1";
$result = mysqli_query($conn,$query);
if($result->num_rows == 1){
  $row = mysqli_fetch_assoc($result);
} 
?>


<div class="row" style="
    margin-left: 61px;
    margin-top: 20px;">
  <form class="form-horizontal" action="edit.php?id=<?php echo $id; ?>&update=yes" method="post">
                <fieldset>

                	<div class="input-group input-group-lg">
                    	<label for="league">Term</label>
                        <input type="text" name="term" value="<?php echo $row['term']; ?>" class="form-control" placeholder="">
                    </div>
                    <div class="clearfix"></div><br>

                    <div class="input-group input-group-lg">
                    	<label for="meaning">Meaning</label>
                        <input type="text" name="meaning" value="<?php echo $row['meaning']; ?>" class="form-control" placeholder="">
                    </div>
                    <div class="clearfix"></div><br>
                   

	              	  <div class="input-group input-group-lg">
	                    <label for="example">Example</label>
	                    <input name="example" type="text" value="<?php echo $row['example']; ?>" class="form-control" placeholder="">
	                  </div>
	                  <div class="clearfix"></div><br> 
                    <input style="display:none;" type="text" name="id" value="<?php echo $row['id']; ?>">
                  
                  <div class="clearfix"></div><br>
                      <div class="input-group input-group-lg">
                      <label for="category">Category</label>
                      <select name="category" class="form-control">
                      <?php $category = $row['category']; ?>
                      <?php $selected = "selected='selected'"; ?>
                        <option <?php if($category == 1){ echo $selected; } ?> value="1">Abbreviations</option>
                        <option <?php if($category == 2){ echo $selected; } ?> value="2">Prefixes</option>
                        <option <?php if($category == 3){ echo $selected; } ?> value="3">Suffixes</option>
                      </select>
                    </div>

                    	<div class="clearfix"></div><br>

                    <p class="center col-md-5">
                        <button type="submit" class="btn btn-primary">Udate</button>
                    </p>
                </fieldset>
            </form>
</div>