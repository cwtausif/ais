<?php include('database.php'); 
   $response = array();
   
   $response["status"] = false;
   $response["message"]="Request Must be Post with all params";
if(!empty($_POST)){
    if(!isset($_POST["email"]) || !isset($_POST["password"])){
        $response["message"]="Email and Password Required";
         echo json_encode($response);
         exit;
    }
    $email = $_POST['email'];
    $password = $_POST['password'];
    
   $query = "SELECT * from ais_users where email = '$email' AND password = '$password' AND type=2";
   
    $result = mysqli_query($conn, $query);
   
    if ($result->num_rows > 0){
        $response["status"] = true;
        $response["message"]="Successfully logged in";
    } else {
         $response["status"] = false;
        $response["message"]="Invalid Login details";
    }
}
 echo json_encode($response);
 exit;
