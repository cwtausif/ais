<?php


require_once('PHPMailer/PHPMailerAutoload.php');

$mail = new PHPMailer();                             
try {
    //Server settings
    $mail->Host ="smtp.gmail.com";
    
    //$mail->isSMTP();
    $mail->SMTPAuth = true;  
    $mail->Username = 'mybusinessreviews2018@gmail.com'; // SMTP username
    $mail->Password = 'mbrs2018';                           // SMTP password
    $mail->SMTPSecure = 'ssl'; 
    
    $mail->Port = 465; 
    //Recipients
    $mail->setFrom('info@glowingsoft.com', 'Business Reviews');
    $mail->addAddress($_POST['email']);     // Add a recipient
                // Name is optional

    

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject  = $_POST['subject'];
    $html ="Please give your best review for the business";
       $html .="<div style='text-decoration: none; font: bold 45px Arial;
  background-color: #EEEEEE;
  color: #333333;
  padding: 2px 6px 2px 6px;
  border-top: 1px solid #CCCCCC;
  border-right: 1px solid #333333;
  border-bottom: 1px solid #333333;
  border-left: 1px solid #CCCCCC; width:615px;'><a style='text-decoration:none; cursor:pointer;'  href='".$_POST["url"]."'>Click here to rate and review</a></div>";
    
    $mail->Body    = $html;
   

    if($mail->send()){
        $response["status"] = true;
        $response["message"] = "Your request has been sent successfully!!!";
    }else {
        $response["status"] = false;
         $response["message"] = "Problem send request";
    }
    
    echo json_encode($response);
    exit;
} catch (Exception $e) {
    $response["status"] = false;
         $response["message"] = "Problem send request";
    
    
    echo json_encode($response);
    exit;
}