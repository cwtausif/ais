<?php session_start(); ?>
<?php include('database.php'); ?>
<?php include('header.php'); ?>
<?php 
//Check user is logged in 
if (isset($_SESSION['userais']) && !empty($_SESSION['userais'])) {
    	
} else {
	echo("<script>location.href = 'login.php';</script>");
}
?>		
<br>
<div class="row"> 
  <form class="form-horizontal" action="adduser.php" method="post">
                <fieldset>
                    
                	<div class="input-group input-group-lg">
                    	<label for="league">Email</label>
                        <input type="text"  name="email" class="form-control">
                        
                    </div>
                    
                 
                     <div class="input-group input-group-lg">
                         <label for="part">Password</label>
                          <input type="text"  name="password" class="form-control">
                        </div>



                            <div class="clearfix"></div><br>
                        <p class="center col-md-5">
                            <button type="submit" class="btn btn-primary">Save</button>
                    </p>
                </fieldset>
            </form>
</div>
<?php

if(!empty($_POST)){
   
   
    $email = $_POST['email'];
    $password = $_POST['password'];
    
  

    if($email =="" || $password == ""){
        echo '<div class="alert alert-danger">All Fields are required</div>';
        exit;
    } else {

    $query = "INSERT INTO `ais_users` (`id`, `email`, `password`, `type`) VALUES (NULL, '$email', '$password','2');";
   	$result = mysqli_query($conn,$query);

   	if ($result) {
   		//header('Location: index.php');
   		echo("<script>location.href = 'users.php';</script>");
   	} else {
   		echo "Failed to save record";
   	}
   }

}
 ?>